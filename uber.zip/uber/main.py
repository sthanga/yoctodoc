import os
import datetime
import logging
import sys

import asyncio
import aiohttp
from aiohttp import ClientTimeout

#from utils import GoogleDriveUploader, GoogleDriveUploaderAsync

from datetime import datetime

from args_parser import WEBSITE_FUNCTIONS, parse_arguments

#from utils import generate_xslx


def fetch_events(website):
    try:
        events_fetch_function = WEBSITE_FUNCTIONS.get(website)
        if events_fetch_function is None:
            raise ValueError("Invalid website name.")
        events = events_fetch_function()
        return events
    except Exception:
        logging.exception(f"An error occurred while fetching events.")


async def main():
    try:
        parser, args = parse_arguments()

        if len(sys.argv) == 1:
            parser.print_help()
            print("No arguments provided. Use -h or --help for usage information.")
            sys.exit(1)

        website = args.website
        events = fetch_events(website=website)      

    except Exception:
        logging.exception(f"An error occurred.")
        print("An error occurred.")

if __name__ == "__main__":
    asyncio.run(main())
