console.log('test');
Element.prototype._attachShadow = Element.prototype.attachShadow;
Element.prototype.attachShadow = function () {
    console.log('attachShadow');
    return this._attachShadow( { mode: "open" } );
};



// Get the host element that contains the shadow root
const hostElement = document.getElementById('transcend-consent-manager');

document.querySelector("#transcend-consent-manager")


input_place = driver.execute_script('return document.querySelector("#shadow_host").shadowRoot.querySelector("#nested_shadow_host").shadowRoot.querySelector("//*[@id="shadow_host"]//input[1]")')
