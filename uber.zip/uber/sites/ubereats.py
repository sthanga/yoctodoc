import json
import time
import logging
from datetime import datetime, timedelta

import requests
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
#from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from utils import deep_get
from driver import CustomWebDriver
import pandas as pd
import re
import requests
from PIL import Image
from io import BytesIO
import os

# Create a folder to store downloaded images
if not os.path.exists('downloaded_images'):
    os.makedirs('downloaded_images')

# for excel data to export
# ========== array elements to fetch each =============== 
#store_names = []
#categories = []
product_names = []
prices = []
weights = []
units = []
#counts = []
image_link = []
photos = []
product_descriptions = []
discount_prices = []
imagenames = []
imageurls  = []
data = []

xpath_value = ['//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[1]/li/div[1]/div[3]/div[3]/button[2]', 
               '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[2]/li/div[1]/div[3]/div[3]/button[2]',
               '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]/li/div[1]/div[3]/div[3]/button[2]']

def image_download(litags):
    for li_imglink in litags :
            try:
                # Skip elements containing 'See all'
                text = li_imglink.text
                if "See all" in text:
                    continue
                
                # Extract the text description from the li tag
                description = li_imglink.text.strip().replace('\n', '').replace('/', '-').replace(' ', '-')
                if description.startswith("$"):
                    # Find the image tag within the li tag
                    img_tag = li_imglink.find_element(By.TAG_NAME, 'img')
                    # Get the image URL
                    img_url = img_tag.get_attribute('src')
                    
                    imageurls.append(img_url)
                    time.sleep(0.2)
                    # Download the image
                    response = requests.get(img_url)
                    time.sleep(0.2)
                    if response.status_code == 200:
                        # Save the image with the li description as filename
                        img_name = f"downloaded_images/{description[:70]}.jpg"  # Limit the filename length to 50 chars
                        with open(img_name, 'wb') as f:
                            f.write(response.content)
                        imagenames.append(img_name)
                    else:
                        print(f"Failed to download image from {img_url}")

            except Exception as e:
                print(f"Error processing li element: {e}")
        
    #print(imagenames)
    #print(imageurls)

def clickUntilDiasble(button, driver, xpathValue):
    # Continuously click the button until it is disabled
    while True:
        
        try:
            # Check if the button is disabled
            if button.get_attribute('disabled'):
                #print("Button is disabled, stopping click loop.")
                break
            # Click the button
            button.click()
            # Optional: Wait for a short time between clicks to allow page updates
            time.sleep(1)
            # Re-find the button to ensure it's refreshed after the page updates
            button = driver.find_element(By.XPATH, xpathValue)

        except Exception as e:
            print(f"Error or button no longer clickable: {e}")
            break

def get_api_params(driver: CustomWebDriver):    
    try:
        driver.get("https://www.ubereats.com/store/joshs-premium-meats/juP_W7vhUrOx5rCuGe1a6Q")
        print(driver.title)

        store_name = driver.find_element(By.XPATH,'//*[@id="main-content"]/div[3]/div/div[1]/div[1]/div/a/h1').text
        print(store_name)

        #working code - inital fetch li tags
        #items = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul') # hq e0 hr
        #li_elements = items.find_elements(By.TAG_NAME, "li") # jc.jd.i8.je.jf
        
        # # for excel data to export
        # # ========== array elements to fetch each =============== 
        # #store_names = []
        # #categories = []
        # product_names = []
        # prices = []
        # weights = []
        # units = []
        # #counts = []
        # image_link = []
        # photos = []
        # product_descriptions = []
        # discount_prices = []
        all_datali = []
        all_data = []
        # ==================== Div Value to scroll ===================
        yvalue =0
        div_value =408
        # ==================== Div Value to scroll ===================
        # import pdb
        # pdb.set_trace()
        print("1\n")
        # ==================== Fetch Element -1 ======================
        items1 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[1]')
        button = driver.find_element(By.XPATH, xpath_value[0])
        clickUntilDiasble(button, driver, xpath_value[0])
        li_elements1 = items1.find_elements(By.TAG_NAME, "li")
        all_datali.append(li_elements1)
        item_list1 = [item.text for item in li_elements1]
        #print (item_list1)
        time.sleep(5)
        all_data.append(item_list1)
        yscroll = yvalue+ div_value
        driver.execute_script(f"window.scrollBy(0,{yscroll});") 
        image_download(li_elements1)

        print("2\n")
        # ==================== Fetch Element -2 ======================
        items2 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[2]')
        button1 = driver.find_element(By.XPATH, xpath_value[1])
        clickUntilDiasble(button1, driver, xpath_value[1])
        li_elements2 = items2.find_elements(By.TAG_NAME, "li") 
        all_datali.append(li_elements2)
        item_list2 = [item.text for item in li_elements2]
        #print (item_list2)
        all_data.append(item_list2)
        yscroll = yvalue+ div_value
        driver.execute_script(f"window.scrollBy(0,{yscroll});") 
        time.sleep(5)
        image_download(li_elements2)
        print("3\n") 
        # ==================== Fetch Element -3 ======================
        items3 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]') # start 
        li_elements3 = items3.find_elements(By.TAG_NAME, "li")     
        all_datali.append(li_elements3)
        item_list3 = [item.text for item in li_elements3]
        #print (item_list3)
        all_data.append(item_list3)
        yscroll = yvalue+ div_value
        driver.execute_script(f"window.scrollBy(0,{yscroll});") 
        time.sleep(2)
        image_download(li_elements3)
        print("4\n")
        
        # ==================== Fetch Element -4 ======================
        items4 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]')
        li_elements4 = items4.find_elements(By.TAG_NAME, "li")     
        all_datali.append(li_elements4)
        item_list4 = [item.text for item in li_elements4]
        #print (item_list4)
        all_data.append(item_list4)
        yscroll = yvalue+ div_value 
        driver.execute_script(f"window.scrollBy(0,{yscroll});") 
        time.sleep(2)
        image_download(li_elements4)
        print("5\n")
        
        # ==================== Fetch Element -5 ======================
        items5 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]')
        li_elements5 = items5.find_elements(By.TAG_NAME, "li")
        all_datali.append(li_elements5)
        item_list5 = [item.text for item in li_elements5]
        #print (item_list5)
        all_data.append(item_list5)
        yscroll = yvalue+ div_value
        driver.execute_script(f"window.scrollBy(0,{yscroll});") 
        time.sleep(2)
        image_download(li_elements5)
        print("6\n")
        
        # ==================== Fetch Element -6 ======================
        items6 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]')
        li_elements6 = items6.find_elements(By.TAG_NAME, "li")
        all_datali.append(li_elements6)
        item_list6 = [item.text for item in li_elements6]
        #print (item_list6)
        all_data.append(item_list6)
        yscroll = yvalue+ div_value
        driver.execute_script(f"window.scrollBy(0,{yscroll});") 
        time.sleep(2)
        image_download(li_elements6)
        print("7\n")
        # ==================== Fetch Element -7 ======================
        items7 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]')
        li_elements7 = items7.find_elements(By.TAG_NAME, "li")
        all_datali.append(li_elements7)
        item_list7 = [item.text for item in li_elements7]
        #print (item_list7)
        all_data.append(item_list7)
        yscroll = yvalue+ div_value
        driver.execute_script(f"window.scrollBy(0,{yscroll});") 
        time.sleep(2)
        image_download(li_elements7)
        print("8\n")

        # ==================== Fetch Element -8 ======================
        items8 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]')
        li_elements8 = items8.find_elements(By.TAG_NAME, "li")
        all_datali.append(li_elements8)
        item_list8 = [item.text for item in li_elements8]
        #print (item_list8)
        all_data.append(item_list8)
        #yscroll = yvalue+ div_value
        driver.execute_script(f"window.scrollBy(0,{yscroll});")
        time.sleep(2)
        image_download(li_elements8)
        print("9\n")
        
        # ==================== Fetch Element -9 ======================
        items9 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]')
        li_elements9 = items9.find_elements(By.TAG_NAME, "li")
        all_datali.append(li_elements9)
        item_list9 = [item.text for item in li_elements9]
        #print (item_list9)
        all_data.append(item_list9)
        yscroll = yvalue+ div_value
        driver.execute_script(f"window.scrollBy(0,{yscroll});")
        time.sleep(2)
        image_download(li_elements9)
        print("10\n")
        
        # ==================== Fetch Element -10 ======================
        items10 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]')
        li_elements10 = items10.find_elements(By.TAG_NAME, "li")
        all_datali.append(li_elements10)
        item_list10 = [item.text for item in li_elements10]
        #print (item_list10)
        all_data.append(item_list10)
        yscroll = yvalue+ div_value
        driver.execute_script(f"window.scrollBy(0,{yscroll});")
        time.sleep(2)
        image_download(li_elements10)
        print("11\n")
        
        # ==================== Fetch Element -11 ======================
        items11 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]')
        li_elements11 = items11.find_elements(By.TAG_NAME, "li")
        all_datali.append(li_elements11)
        item_list11 = [item.text for item in li_elements11]
        #print (item_list11)
        all_data.append(item_list11)
        #yscroll = yvalue + div_value
        driver.execute_script(f"window.scrollBy(0,{yscroll});")
        image_download(li_elements11)
        time.sleep(2)          
        print("12\n")
        
        # ==================== Fetch Element -12 ======================
        items12 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]')
        li_elements12 = items12.find_elements(By.TAG_NAME, "li")
        all_datali.append(li_elements12)
        item_list12 = [item.text for item in li_elements12]
        #print (item_list12)
        all_data.append(item_list12)
        yscroll = yvalue+ div_value
        driver.execute_script(f"window.scrollBy(0,{yscroll});")
        time.sleep(2)
        image_download(li_elements12)
        print("13\n")
        
        # ==================== Fetch Element -13 ======================
        items13 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]')
        li_elements13 = items13.find_elements(By.TAG_NAME, "li")
        all_datali.append(li_elements13)
        item_list13 = [item.text for item in li_elements13]
        #print (item_list13)
        all_data.append(item_list13)
        #yscroll = yvalue+ div_value   # to be included in the 
        driver.execute_script(f"window.scrollBy(0,{yscroll});") 
        image_download(li_elements13)
        time.sleep(2)    
        # ==================== Fetch Element -14 ======================
        print("14 \n")
        items14 = driver.find_element(By.XPATH, '//*[@id="main-content"]/div[3]/div/div[2]/div/div/ul/div/div[3]')
        li_elements14 = items14.find_elements(By.TAG_NAME, "li")
        all_datali.append(li_elements14)
        item_list14 = [item.text for item in li_elements14]
        #print (item_list14)
        all_data.append(item_list14)
        yscroll = yvalue+ div_value
        driver.execute_script(f"window.scrollBy(0,{yscroll});")
        image_download(li_elements14)

        temp_date=0
        #Iterate through the <li> elements and extract data
        for item_list in all_data:
            temp = 0
            for li in item_list:
                lines = li.split('\n')
                # Check if it starts with a category (e.g., Seafood) that includes "See all"
                if len(lines) > 1 and 'See all' in lines[1]:
                    category = lines[0]  # First line is the category
                    temp=1

                else:
                    if (temp==0):
                       category = lines[0] 
                       temp =1
                       print (category)
                    
                    # Handle items that do not have the "See all" tag (just products and prices)
                    elif len(lines) >= 2:  # Ensure there's enough data to process
                        price = lines[0]
                        temp =1
                        product_nameli = lines[1]
                        discount_prices = None
                        #photos = None
                        
                        # Use regex to split product name, weight, and unit
                        product_descriptions = product_nameli
                        if product_descriptions:
                            pattern = r'(.+?)\s*\(([\d\w\s\-\/]+)\)(?:\s*\((.+?)\))?'
                            match = re.match(pattern, product_nameli)

                            if match:
                                product_names = match.group(1).strip()  # Product name
                                weights = match.group(2).strip()        # Weight
                                units = match.group(3).strip() if match.group(3) else None  # Unit (if exists)

                        #print("else part", "--", price, "--", product_nameli, "---", weights)

                        # Add the processed data to the final list
                        data.append([store_name, category, product_descriptions, product_names, weights, units, price, imagenames[temp_date], imageurls[temp_date], discount_prices])
                        temp_date = temp_date + 1


 
        # Step 2: Create a DataFrame with the extracted data
        df = pd.DataFrame(data, columns=['Store_name','Category','product_descriptions','Product Name', 'Weight/Quantity', 'Units/Counts', 'Price', 'image_file_names','Image_Link','Discount'])

        # Step 3: Export to Excel
        df.to_excel('products.xlsx', index=False)

        return all_data
        
    except Exception:
        logging.exception(f"Error occurred while retrieving API Params.")
        return None


def fetch_events_from_eventbrite():
    try:
        driver  = CustomWebDriver(headless=False)
        place_id = get_api_params(driver)
        driver.quit()

        event_data = []

        # for query in queries:
        #     event_data.extend(scrape_event_data(place_id=place_id, csrf_token=csrf_token, dates=dates))

        return event_data

    except Exception:
        logging.exception(f"Error occurred during event data scraping and processing.")


if __name__ == "__main__":
    fetch_events_from_eventbrite()
