import pathlib
import os
from datetime import datetime


CWD = pathlib.Path(__file__).cwd()

#DRIVER_PATH = pathlib.Path("/home/ubuntu/events-scrap/drivers/chromedriver")
DRIVER_PATH = CWD / 'drivers/chromedriver'
if DRIVER_PATH.exists():
    pass
else:
    # pass
    raise FileNotFoundError(f"The driver path '{DRIVER_PATH}' does not exist.")

XPATH_DIR = CWD / 'xpath'

SERVICE_ACCOUNT_CREDS = CWD / 'file-scraping-983c52577b59.json'

if SERVICE_ACCOUNT_CREDS.exists():
    pass
else:
    pass
    # raise FileNotFoundError(f"The service account credentials '{SERVICE_ACCOUNT_CREDS}' does not exist.")

OUTPUT_FOLDER = CWD / "EventReports" / datetime.today().strftime("%Y-%m-%d")
OUTPUT_REPORTS_FOLDER = OUTPUT_FOLDER / "RelReports"
OUTPUT_IMAGE_FOLDER = OUTPUT_FOLDER / "RelImages"

if OUTPUT_FOLDER.exists() and OUTPUT_REPORTS_FOLDER.exists() and OUTPUT_IMAGE_FOLDER.exists():
    pass
else:
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    os.makedirs(OUTPUT_REPORTS_FOLDER, exist_ok=True)
    os.makedirs(OUTPUT_IMAGE_FOLDER, exist_ok=True)


# For 10times.com
AWS_KEY_ID = "AKIAZIBUDUHYDIAVAAXE"
AWS_SECRET_ACCESS_KEY = "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"

# AWS_KEY_ID = "AKIASWL536VDS7XB4B6T"
# AWS_SECRET_ACCESS_KEY = "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"

# AWS_KEY_ID = "AKIASWL536VD2ULTAZGB"
# AWS_SECRET_ACCESS_KEY = "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"
