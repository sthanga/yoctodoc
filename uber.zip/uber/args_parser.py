import argparse

#from sites.allevents import fetch_events_from_allevents
#from sites.eventbrite import 
#from sites.google_events import fetch_events_from_google_events
#from sites.meetup import fetch_events_from_meetup
from sites.ubereats import fetch_events_from_eventbrite


WEBSITE_FUNCTIONS = {
   # "eventbrite.com": fetch_events_from_eventbrite,
   # "allevents.in": fetch_events_from_allevents,
   # "googleevents": fetch_events_from_google_events,
   # "meetup.com": fetch_events_from_meetup,
   "ubereats.com": fetch_events_from_eventbrite,
}


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Religious event web scraping Tool",
        formatter_class=argparse.RawTextHelpFormatter,
    )

    scrapping_group = parser.add_argument_group(
        "Scraping arguments", description="Scraping related parameters"
    )

    scrapping_group.add_argument(
        "-w",
        "--website",
        metavar="WEBSITE",
        type=str,
        choices=WEBSITE_FUNCTIONS.keys(),
        help="Enter the name of the website:\n" +
        "\n".join([f"  - {choice}" for choice in WEBSITE_FUNCTIONS.keys()])+"\n",
    )

    scrapping_group.add_argument(
        "-c", "--city", metavar=None, type=str, default="Miami", help="Enter the name of the city\n"
    )

    scrapping_group.add_argument(
        "-d", "--days", metavar=None, type=int, default=1, help="Enter the number of days\n"
    )
    
    scrapping_group.add_argument(
        "-s", "--storage", metavar='STORAGE', type=str, choices= ['local', 'google_drive', 'both'], default='google_drive'
        ,help="Choose storage option:\n- local\n- google_drive\n- both"
        
    )

    args = parser.parse_args()
    return parser, args
